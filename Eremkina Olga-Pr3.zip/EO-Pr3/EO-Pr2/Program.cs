﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr3
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Human> humans = new List<Human>();
            humans.Add(new RusH(17));
            humans.Add(new EngH(28));
            humans.Add(new FranH(30));
            RusH R = new RusH(12);
            EngH E = new EngH(22);
            FranH F = new FranH(25);
            humans.Add(R);
            humans.Add(E);
            humans.Add(F);
            R.Name = "Иван";
            F.Name = "Oliver";
            E.Name = "Paul";
            Console.WriteLine("Коллекция:");
            foreach (Human h in humans)
                Console.WriteLine("{0} - {1} - {2}", h.Name, h.Age, h.Type);
            //int or;
            //Random Arnd = new Random();
            //or = Arnd.Next(1, 5);
            //switch (or)
            //{
            //    case 1:
            //        R.SayHi();
            //        Console.WriteLine("Меня зовут {0}", R.Name);
            //        R.Origin();
            //        break;
            //    case 2:
            //        E.SayHi();
            //        Console.WriteLine("My name is {0}", E.Name);
            //        E.Origin();
            //        break;
            //    case 3:
            //        F.SayHi();
            //        Console.WriteLine("Je m'appelle {0}", F.Name);
            //        F.Origin();
            //        break;
            //    default:
            //        Console.WriteLine("Ошибка");
            //        break;
            //}
            Console.WriteLine();
            Console.WriteLine("Отсортированная коллекция:");
            var sortedHumans = from h in humans
                              orderby h.Age
                               select h;
            foreach (Human h in sortedHumans)
                Console.WriteLine("{0} - {1} - {2}", h.Name, h.Age, h.Type);

            Console.ReadKey();
        }          
    } 
}

