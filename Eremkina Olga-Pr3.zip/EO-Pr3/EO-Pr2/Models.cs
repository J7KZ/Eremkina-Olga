﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr2
{
    abstract class Models
    {
        public int RS
        {
        get;
        set;
        }
            
    }
}
