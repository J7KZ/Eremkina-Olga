﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr3
{
    class RusH : Human
    {
        
        public RusH (int age)
        {
            Name = "Федор";
            Age = age;
            Type = "Русский";
        }
        public override void Origin()
        {
            Console.WriteLine("Моя страна Россия");
        }
        public override void SayHi()
        {
            Console.WriteLine ("Привет!");
            
        }        
    }
}
