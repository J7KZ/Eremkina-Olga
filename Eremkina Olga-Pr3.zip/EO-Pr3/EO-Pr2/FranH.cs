﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr3
{
    class FranH : Human
    {

        public FranH(int age)
        {
            Name = "Joe";
            Age = age;
            Type = "Le français";
        }
        public override void Origin()
        {
           Console.WriteLine("Mon pays la France");
        }

        public override void SayHi()
        {
            Console.WriteLine("Salut!");
        }
    }
}
